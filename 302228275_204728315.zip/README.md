<b><u>IDs:</u></b> Nadav Spitzer 302228275, Lior Frenkel 204728315
# Deep-Learning-Window-based-Tagging

#### Part 1:
<u><b>Files:</b></u> tagger1.py, utils.py, main_part1.py<br>
<u><b>Run:</b></u> python main_part1.py <i><task_type></i>
<br>Where <i><task_type></i> is either 'pos' or 'ner' (lower case).


#### Part 3:

<u><b>Files:</b></u> tagger2.py, utils.py, main_part3.py
<br><u><b>Run:</b></u> python main_part3.py <i><task_type></i>
<br>Where <i><task_type></i> is either 'pos' or 'ner' (lower case).


#### Part 4:

<u><b>Files:</b></u> tagger3.py, utils.py, main_part4.py
<br><u><b>Run:</b></u> python main_part3.py <i><task_type> <is_pretrained></i>
<br>Where <i><task_type></i> is either 'pos' or 'ner' (lower case) and <i><is_pretrained></i> is either True/False.


#### Part 5:

<u><b>Files:</b></u> tagger4.py, utils.py, main_part5.py
<br><u><b>Run:</b></u> python main_part4.py <i><task_type></i>
<br>Where <i><task_type></i> is either 'pos' or 'ner' (lower case).
